import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyATnkFt8BqGvLLfPlbso5pzNbO52ZzOOi0",
    authDomain: "puntopedidos-8da46.firebaseapp.com",
    projectId: "puntopedidos-8da46",
    storageBucket: "puntopedidos-8da46.appspot.com", // Corregí el dominio del storage.
    messagingSenderId: "237509886095",
    appId: "1:237509886095:web:d1365435417b54c45670fa",
    measurementId: "G-0CC67EWEM9"
  }
};



// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
