import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { environment } from '../environments/environment';

// Inicialización de Firebase
const firebaseApp = initializeApp(environment.firebaseConfig);

// Inicialización de Analytics (opcional)
const analytics = getAnalytics(firebaseApp);

export { firebaseApp, analytics };
