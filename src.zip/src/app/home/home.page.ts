import { Component, OnInit } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {
  products: any[] = [];

  constructor(private afs: AngularFirestore, private router: Router) {}

  ngOnInit() {
    this.afs.collection('products').valueChanges({ idField: 'id' }).subscribe(data => {
      this.products = data;
    });
  }

  viewProduct(product: any) {
    this.router.navigate(['/product-detail', product.id]);
  }
}
