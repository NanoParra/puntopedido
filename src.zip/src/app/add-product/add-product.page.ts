import { Component } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { AngularFireStorage } from '@angular/fire/compat/storage';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.page.html',
  styleUrls: ['./add-product.page.scss'],
})
export class AddProductPage {
  productName: string = '';
  productDescription: string = '';
  productPrice: number = 0;
  productCategory: string = '';
  imageFile: File | null = null;
  imagePreview: string | null = null;

  constructor(private afs: AngularFirestore, private storage: AngularFireStorage) {}

  selectImage(event: any) {
    const file = event.target.files[0];
    if (file) {
      this.imageFile = file;

      // Mostrar vista previa de la imagen
      const reader = new FileReader();
      reader.onload = () => {
        this.imagePreview = reader.result as string;
      };
      reader.readAsDataURL(file);
    }
  }

  async addProduct() {
    if (!this.imageFile) {
      console.error('Debe seleccionar una imagen');
      return;
    }

    const filePath = `products/${Date.now()}_${this.imageFile.name}`;
    const fileRef = this.storage.ref(filePath);

    try {
      await this.storage.upload(filePath, this.imageFile);
      const imageUrl = await fileRef.getDownloadURL().toPromise();

      await this.afs.collection('products').add({
        name: this.productName,
        description: this.productDescription,
        price: this.productPrice,
        category: this.productCategory,
        imageUrl,
      });

      console.log('Producto agregado exitosamente');
    } catch (error) {
      console.error('Error al agregar el producto:', error);
    }
  }
}
