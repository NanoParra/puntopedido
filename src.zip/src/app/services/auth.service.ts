import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private afAuth: AngularFireAuth, private router: Router) { }

  // Registro de usuario
  async register(email: string, password: string) {
    try {
      await this.afAuth.createUserWithEmailAndPassword(email, password);
      this.router.navigate(['/home']);  // Redirigir al home después de registrarse
    } catch (error) {
      console.error('Error en el registro', error);
    }
  }

  // Inicio de sesión de usuario
  async login(email: string, password: string) {
    try {
      await this.afAuth.signInWithEmailAndPassword(email, password);
      this.router.navigate(['/home']);  // Redirigir al home después de iniciar sesión
    } catch (error) {
      console.error('Error en el login', error);
    }
  }

  // Cerrar sesión
  async logout() {
    try {
      await this.afAuth.signOut();
      this.router.navigate(['/login']);  // Redirigir a la página de login
    } catch (error) {
      console.error('Error al cerrar sesión', error);
    }
  }
}
